# Front

npm install

npm install -g yarn

yarn install

node 설치는 nodejs20.15.1 설치 해야됩니다.


yarn add zustand
yarn add @react-native-async-storage/async-storage


yarn web

